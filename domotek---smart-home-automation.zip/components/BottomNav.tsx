
import React from 'react';
import { NavLink } from 'react-router-dom';
import { HomeIcon, ZapIcon, UsersIcon, BotIcon, MailIcon } from './Icons';

const NavItem: React.FC<{ to: string; icon: React.ReactNode; label: string }> = ({ to, icon, label }) => (
  <NavLink
    to={to}
    className={({ isActive }) =>
      `flex flex-col items-center justify-center space-y-1 w-full transition-colors duration-200 ${
        isActive ? 'text-blue-400' : 'text-gray-400 hover:text-white'
      }`
    }
  >
    {icon}
    <span className="text-xs font-medium">{label}</span>
  </NavLink>
);

const BottomNav: React.FC = () => {
  return (
    <div className="absolute bottom-0 left-0 right-0 h-20 bg-black/50 backdrop-blur-lg border-t border-gray-800/50">
      <div className="flex justify-around items-center h-full max-w-sm mx-auto px-2">
        <NavItem to="/" icon={<HomeIcon className="w-6 h-6" />} label="Inicio" />
        <NavItem to="/solutions" icon={<ZapIcon className="w-6 h-6" />} label="Soluciones" />
        <NavItem to="/assistant" icon={<BotIcon className="w-7 h-7" />} label="Asesoría" />
        <NavItem to="/nosotros" icon={<UsersIcon className="w-6 h-6" />} label="Nosotros" />
        <NavItem to="/contacto" icon={<MailIcon className="w-6 h-6" />} label="Contacto" />
      </div>
    </div>
  );
};

export default BottomNav;
