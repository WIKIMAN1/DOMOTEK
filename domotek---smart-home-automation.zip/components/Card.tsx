import React from 'react';

// FIX: Update CardProps to accept onClick and other standard div attributes.
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '', ...props }) => {
  return (
    <div {...props} className={`bg-slate-900/40 backdrop-blur-lg border border-blue-500/25 rounded-2xl p-4 shadow-lg shadow-blue-900/50 transition-all hover:border-blue-400/50 ${className}`}>
      {children}
    </div>
  );
};

export default Card;