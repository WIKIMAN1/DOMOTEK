
import React from 'react';

interface EnergyGaugeProps {
  percentage: number;
  label: string;
}

const EnergyGauge: React.FC<EnergyGaugeProps> = ({ percentage, label }) => {
  const radius = 50;
  const stroke = 8;
  const normalizedRadius = radius - stroke * 2;
  const circumference = normalizedRadius * 2 * Math.PI;
  const strokeDashoffset = circumference - (percentage / 100) * circumference;

  return (
    <div className="relative flex flex-col items-center justify-center">
      <svg
        height={radius * 2}
        width={radius * 2}
        className="-rotate-90"
      >
        <defs>
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" style={{stopColor: "#38bdf8", stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: "#818cf8", stopOpacity: 1}} />
            </linearGradient>
        </defs>
        <circle
          stroke="#374151"
          fill="transparent"
          strokeWidth={stroke}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
        />
        <circle
          stroke="url(#gaugeGradient)"
          fill="transparent"
          strokeWidth={stroke}
          strokeDasharray={circumference + ' ' + circumference}
          style={{ strokeDashoffset, strokeLinecap: 'round' }}
          r={normalizedRadius}
          cx={radius}
          cy={radius}
          className="transition-all duration-1000 ease-in-out"
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-4xl font-bold text-white">{percentage}%</span>
        <span className="text-sm text-gray-400 mt-1">{label}</span>
      </div>
    </div>
  );
};

export default EnergyGauge;
