
import React from 'react';
import BottomNav from './BottomNav';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="h-full flex flex-col text-white bg-gradient-to-b from-[#1a1a3d] via-[#111827] to-[#0c0c1e]">
      <main className="flex-grow overflow-y-auto pb-24">
        {children}
      </main>
      <BottomNav />
    </div>
  );
};

export default Layout;
