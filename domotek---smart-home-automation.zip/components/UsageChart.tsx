
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const data = [
  { name: 'Lun', 'Actividad': 10, 'Consumo Energético': 8 },
  { name: 'Mar', 'Actividad': 15, 'Consumo Energético': 12 },
  { name: 'Mié', 'Actividad': 35, 'Consumo Energético': 28 },
  { name: 'Jue', 'Actividad': 22, 'Consumo Energético': 25 },
  { name: 'Vie', 'Actividad': 38, 'Consumo Energético': 32 },
  { name: 'Sáb', 'Actividad': 18, 'Consumo Energético': 15 },
  { name: 'Dom', 'Actividad': 12, 'Consumo Energético': 10 },
];

const CustomTooltip: React.FC<any> = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-slate-800/80 backdrop-blur-sm p-3 rounded-lg border border-slate-700">
                <p className="text-sm text-gray-300">{label}</p>
                {payload.map((pld: any) => (
                    <div key={pld.dataKey} style={{ color: pld.color }} className="text-xs font-medium">
                        {pld.dataKey}: {pld.value}%
                    </div>
                ))}
            </div>
        );
    }
    return null;
};

const UsageChart: React.FC = () => {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <AreaChart data={data} margin={{ top: 20, right: 10, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="colorActivity" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.4}/>
            <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0}/>
          </linearGradient>
          <linearGradient id="colorEnergy" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor="#818cf8" stopOpacity={0.4}/>
            <stop offset="95%" stopColor="#818cf8" stopOpacity={0}/>
          </linearGradient>
        </defs>
        <XAxis dataKey="name" stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} />
        <YAxis stroke="#9ca3af" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}%`} />
        <Tooltip content={<CustomTooltip />} />
        <Legend 
            verticalAlign="top" 
            align="right" 
            iconType="circle" 
            wrapperStyle={{ top: -10 }} 
            formatter={(value) => <span className="text-gray-300 text-xs">{value}</span>}
        />
        <Area type="monotone" dataKey="Actividad" stroke="#2dd4bf" strokeWidth={2} fillOpacity={1} fill="url(#colorActivity)" />
        <Area type="monotone" dataKey="Consumo Energético" stroke="#818cf8" strokeWidth={2} fillOpacity={1} fill="url(#colorEnergy)" />
      </AreaChart>
    </ResponsiveContainer>
  );
};

export default UsageChart;
