import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import { LightbulbIcon, ThermometerIcon, ZapIcon, ChevronRightIcon } from '../components/Icons';

const AIScanScreen: React.FC = () => {
    const navigate = useNavigate();
    const [scanning, setScanning] = useState(true);

    useEffect(() => {
        const timer = setTimeout(() => setScanning(false), 4000);
        return () => clearTimeout(timer);
    }, []);

    return (
        <div className="h-full flex flex-col p-4 space-y-6 overflow-hidden">
            <header className="flex items-center relative">
                <button onClick={() => navigate(-1)} className="text-white p-2 absolute left-0">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
                </button>
                <h1 className="text-xl font-semibold text-center w-full text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
                  Escaneo IA de Hogar
                </h1>
            </header>

            {scanning ? (
                <div className="flex-grow flex flex-col items-center justify-center text-center">
                    <div className="relative w-48 h-48">
                        <div className="absolute inset-0 border-4 border-blue-500/30 rounded-full"></div>
                        <div className="absolute inset-0 border-4 border-blue-500 rounded-full animate-ping"></div>
                        <div className="absolute inset-0 flex items-center justify-center">
                           <svg className="w-24 h-24 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
                           </svg>
                        </div>
                    </div>
                    <p className="mt-8 text-lg font-semibold text-white animate-pulse">Analizando estructura y consumo...</p>
                    <p className="text-gray-400 mt-2 text-sm">Modelando tu hogar en 3D para un análisis energético completo.</p>
                </div>
            ) : (
                <div className="flex-grow overflow-y-auto animate-fade-in space-y-4 pb-20">
                    <h2 className="text-xl font-bold text-center">Resultados del Análisis</h2>
                    <p className="text-center text-gray-400 text-sm mb-4">Hemos identificado oportunidades clave para mejorar tu eficiencia.</p>
                    
                    <Card className="border-green-400/40 hover:border-green-400/80">
                        <div className="flex items-center space-x-4">
                            <div className="p-3 bg-green-500/20 rounded-full"><LightbulbIcon className="w-6 h-6 text-green-400"/></div>
                            <div>
                                <h3 className="font-semibold">Optimización de Iluminación</h3>
                                <p className="text-xs text-gray-400">Recomendamos cambiar 5 bombillas a LED inteligentes para un ahorro estimado del 15% en iluminación.</p>
                            </div>
                        </div>
                    </Card>
                    <Card className="border-yellow-400/40 hover:border-yellow-400/80">
                        <div className="flex items-center space-x-4">
                            <div className="p-3 bg-yellow-500/20 rounded-full"><ThermometerIcon className="w-6 h-6 text-yellow-400"/></div>
                            <div>
                                <h3 className="font-semibold">Aislamiento Térmico</h3>
                                <p className="text-xs text-gray-400">Detectamos una fuga de calor en la ventana del salón. Sellarla podría reducir el uso de calefacción en un 8%.</p>
                            </div>
                        </div>
                    </Card>
                    <Card className="border-red-400/40 hover:border-red-400/80">
                         <div className="flex items-center space-x-4">
                            <div className="p-3 bg-red-500/20 rounded-full"><ZapIcon className="w-6 h-6 text-red-400"/></div>
                            <div>
                                <h3 className="font-semibold">Consumo Fantasma</h3>
                                <p className="text-xs text-gray-400">El sistema de entretenimiento consume 30W en standby. Un enchufe inteligente podría eliminar este gasto.</p>
                            </div>
                        </div>
                    </Card>
                     <button 
                        onClick={() => navigate('/solutions')}
                        className="w-full mt-6 flex justify-between items-center bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-3 px-4 rounded-xl shadow-lg shadow-blue-500/20 hover:scale-105 transition-transform">
                        <span>Ver Equipos Recomendados</span>
                        <ChevronRightIcon className="w-6 h-6"/>
                      </button>
                </div>
            )}
        </div>
    );
};

export default AIScanScreen;
