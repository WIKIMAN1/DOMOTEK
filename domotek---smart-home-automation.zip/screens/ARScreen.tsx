import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CameraIcon, PowerIcon, LightbulbIcon, ThermometerIcon, ZapIcon } from '../components/Icons';

const ARScreen: React.FC = () => {
  const navigate = useNavigate();
  const [selectedDevice, setSelectedDevice] = useState('light');

  const devices = [
    { id: 'camera', icon: <CameraIcon />, name: 'Cámara', position: { top: '30%', left: '20%' } },
    { id: 'power', icon: <PowerIcon />, name: 'Enchufe', position: { top: '55%', left: '70%' } },
    { id: 'light', icon: <LightbulbIcon />, name: 'Luz', position: { top: '45%', left: '45%' } },
  ];

  return (
    <div className="h-full flex flex-col bg-black">
      <header className="absolute top-0 left-0 right-0 z-20 flex items-center p-4 bg-gradient-to-b from-black/70 to-transparent">
        <button onClick={() => navigate(-1)} className="text-white p-2">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
        </button>
        <h1 className="text-xl font-semibold text-white mx-auto" style={{textShadow: '0 0 5px rgba(255, 255, 255, 0.7)'}}>Asesoría con RA</h1>
      </header>

      <div className="flex-grow relative">
        <img src="https://picsum.photos/id/1069/400/800" alt="Living Room" className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-black/40"></div>
        
        <div className="absolute top-20 left-4 right-4 z-10 p-3 bg-black/50 backdrop-blur-md rounded-lg border border-blue-500/30">
            <p className="text-xs text-center text-gray-200">Visualiza nuestros productos en tu propio espacio. Selecciona un dispositivo abajo y toca en la pantalla para ver cómo quedaría.</p>
        </div>

        {devices.map(device => (
            <div key={device.id} className="absolute" style={device.position}>
                <div className={`relative w-12 h-12 flex items-center justify-center rounded-full transition-all duration-300 ${selectedDevice === device.id ? 'bg-blue-500/50' : 'bg-black/50'}`}>
                    <div className={`w-10 h-10 flex items-center justify-center rounded-full ${selectedDevice === device.id ? 'bg-blue-500' : 'bg-gray-800'}`}>
                        {React.cloneElement(device.icon, { className: 'w-6 h-6 text-white' })}
                    </div>
                    {selectedDevice === device.id && <div className="absolute inset-0 rounded-full border-2 border-blue-400 animate-ping"></div>}
                </div>
            </div>
        ))}
        
        <svg className="absolute inset-0 w-full h-full" style={{ pointerEvents: 'none' }}>
            <defs>
                <linearGradient id="lineGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" style={{ stopColor: '#38bdf8', stopOpacity: 1 }} />
                    <stop offset="100%" style={{ stopColor: '#a78bfa', stopOpacity: 1 }} />
                </linearGradient>
            </defs>
            <line x1="26%" y1="34%" x2="50%" y2="49%" stroke="url(#lineGrad)" strokeWidth="1.5" strokeDasharray="4" opacity="0.7"/>
            <line x1="76%" y1="59%" x2="50%" y2="49%" stroke="url(#lineGrad)" strokeWidth="1.5" strokeDasharray="4" opacity="0.7"/>
        </svg>
      </div>

      <div className="absolute bottom-28 left-0 right-0 p-4 z-10">
        <div className="flex justify-center items-center space-x-2 sm:space-x-4 bg-black/60 backdrop-blur-md p-2 rounded-full max-w-sm mx-auto">
          <button onClick={() => setSelectedDevice('camera')} className={`p-3 rounded-full transition-colors ${selectedDevice === 'camera' ? 'bg-blue-500' : 'bg-gray-700/50 hover:bg-gray-700'}`}><CameraIcon className="w-6 h-6 text-white"/></button>
          <button onClick={() => setSelectedDevice('power')} className={`p-3 rounded-full transition-colors ${selectedDevice === 'power' ? 'bg-blue-500' : 'bg-gray-700/50 hover:bg-gray-700'}`}><PowerIcon className="w-6 h-6 text-white"/></button>
          <button onClick={() => setSelectedDevice('light')} className={`p-3 rounded-full transition-colors ${selectedDevice === 'light' ? 'bg-blue-500' : 'bg-gray-700/50 hover:bg-gray-700'}`}><LightbulbIcon className="w-6 h-6 text-white"/></button>
          <button onClick={() => setSelectedDevice('thermo')} className={`p-3 rounded-full transition-colors ${selectedDevice === 'thermo' ? 'bg-blue-500' : 'bg-gray-700/50 hover:bg-gray-700'}`}><ThermometerIcon className="w-6 h-6 text-white"/></button>
          <button onClick={() => setSelectedDevice('zap')} className={`p-3 rounded-full transition-colors ${selectedDevice === 'zap' ? 'bg-blue-500' : 'bg-gray-700/50 hover:bg-gray-700'}`}><ZapIcon className="w-6 h-6 text-white"/></button>
        </div>
      </div>
       <div className="absolute bottom-0 left-0 right-0 p-4 pb-24 z-10 bg-gradient-to-t from-black/80 to-transparent">
        <button className="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-bold py-4 px-4 rounded-2xl shadow-lg shadow-blue-500/20 hover:scale-105 transition-transform">
          Agendar Sesión de Asesoría
        </button>
      </div>
    </div>
  );
};

export default ARScreen;