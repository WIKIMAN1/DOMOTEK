import React from 'react';
import Card from '../components/Card';
import { ChevronRightIcon } from '../components/Icons';

const AboutScreen: React.FC = () => {
  return (
    <div className="p-4 space-y-6 animate-fade-in">
      <header className="text-center">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
          Acerca de DOMOTEK
        </h1>
        <p className="text-gray-300 mt-2">Creando hogares proactivos y sensibles en Ecuador.</p>
      </header>

      <Card>
        <h2 className="text-xl font-semibold text-blue-300 mb-2">Nuestra Misión</h2>
        <p className="text-gray-400 text-sm">
          Nuestra misión es integrar tecnología de inteligencia artificial de vanguardia para transformar los hogares en espacios proactivos y sensibles que anticipan y responden a las necesidades de sus habitantes, mejorando su calidad de vida, seguridad y eficiencia energética.
        </p>
      </Card>

      <Card>
        <h2 className="text-xl font-semibold text-blue-300 mb-2">Nuestra Visión</h2>
        <p className="text-gray-400 text-sm">
          Ser la empresa líder en domótica inteligente en Ecuador, reconocida por nuestra innovación, la calidad de nuestro soporte proactivo y predictivo, y por crear experiencias de hogar conectado verdaderamente personalizadas y futuristas.
        </p>
      </Card>
      
      <Card>
        <h2 className="text-xl font-semibold text-blue-300 mb-2">¿Por qué DOMOTEK?</h2>
        <ul className="space-y-3 text-sm text-gray-400">
            <li className="flex items-start space-x-2">
                <ChevronRightIcon className="w-4 h-4 text-blue-400 mt-1 flex-shrink-0" />
                <span><strong className="text-white">IA Avanzada:</strong> Nuestro sistema aprende de tus rutinas para optimizar tu hogar automáticamente.</span>
            </li>
            <li className="flex items-start space-x-2">
                <ChevronRightIcon className="w-4 h-4 text-blue-400 mt-1 flex-shrink-0" />
                <span><strong className="text-white">Soporte Proactivo:</strong> Detectamos y solucionamos problemas antes de que te afecten.</span>
            </li>
            <li className="flex items-start space-x-2">
                <ChevronRightIcon className="w-4 h-4 text-blue-400 mt-1 flex-shrink-0" />
                <span><strong className="text-white">Asesoría con RA:</strong> Visualiza el futuro de tu hogar con nuestra tecnología de Realidad Aumentada.</span>
            </li>
        </ul>
      </Card>
    </div>
  );
};

export default AboutScreen;
