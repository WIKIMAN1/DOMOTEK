
import React from 'react';
import Card from '../components/Card';
import EnergyGauge from '../components/EnergyGauge';
import { BotIcon, ChevronRightIcon } from '../components/Icons';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';
import { useNavigate } from 'react-router-dom';

const chartData = [
    { name: 'Lun', uv: 10 },
    { name: 'Mar', uv: 15 },
    { name: 'Mié', uv: 35 },
    { name: 'Jue', uv: 22 },
    { name: 'Vie', uv: 38 },
    { name: 'Sáb', uv: 18 },
    { name: 'Dom', uv: 12 },
];


const AssistantScreen: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="p-4 space-y-6">
      <header className="text-center space-y-4">
        <h1 className="text-xl font-semibold">Asistente</h1>
        <div className="inline-block p-5 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full shadow-lg">
          <BotIcon className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-2xl font-bold">¡Hola! Soy tu asistente de IA.</h2>
        <p className="text-gray-400 max-w-xs mx-auto">
          Puedo ayudarte a controlar tus dispositivos inteligentes y a interactuar con tu hogar de nuevas maneras.
        </p>
      </header>

      <div className="flex justify-center gap-4">
        <button 
          onClick={() => navigate('/ar')}
          className="bg-gray-700/80 text-white font-semibold py-2 px-6 rounded-lg border border-gray-600 hover:bg-gray-700 transition-colors">
          Activar AR
        </button>
        <button className="bg-gray-700/80 text-white font-semibold py-2 px-6 rounded-lg border border-gray-600 hover:bg-gray-700 transition-colors">
          Historial
        </button>
      </div>

      <section>
        <h3 className="text-lg font-semibold mb-2">Mi Rutina Energética</h3>
        <p className="text-sm text-gray-400 mb-4">Aprendizaje de Patrones: 80% completado</p>
        <div className="h-24">
            <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                    <defs>
                        <linearGradient id="assistantChartGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#2dd4bf" stopOpacity={0.6}/>
                            <stop offset="95%" stopColor="#2dd4bf" stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <Area type="monotone" dataKey="uv" stroke="#2dd4bf" strokeWidth={2} fill="url(#assistantChartGradient)" />
                </AreaChart>
            </ResponsiveContainer>
        </div>
        <div className="flex justify-between items-center text-sm mt-2 border-t border-gray-700/50 pt-3">
            <span className="text-gray-400">Hora de Dormir:</span>
            <span className="font-semibold">11:30 PM</span>
        </div>
        <div className="flex justify-between items-center text-sm mt-2">
            <span className="text-gray-400">Despertador:</span>
            <span className="font-semibold">7:00 AM (Aprendido)</span>
        </div>
      </section>

      <section>
        <h3 className="text-lg font-semibold mb-4">Dashboard de Ahorro</h3>
        <div className="grid grid-cols-2 gap-4">
            <Card className="flex flex-col items-center justify-center p-2">
                <EnergyGauge percentage={35} label="Ahorro Energético" />
                 <p className="text-xs text-center text-gray-400 mt-2">Dispositivos en Standby</p>
            </Card>
            <div className="space-y-4">
                 <Card>
                    <h4 className="font-bold">Control Total</h4>
                    <p className="text-xs text-gray-400 mt-1">Controla tu hogar desde una interfaz intuitiva.</p>
                </Card>
                 <Card>
                    <h4 className="font-bold">Eficiencia Energética</h4>
                    <p className="text-xs text-gray-400 mt-1">Disfruta del hogar con sistemas eficientes.</p>
                </Card>
            </div>
        </div>
      </section>

    </div>
  );
};

export default AssistantScreen;
