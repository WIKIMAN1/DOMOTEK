import React from 'react';
import Card from '../components/Card';
import { MailIcon } from '../components/Icons';

const ContactScreen: React.FC = () => {
  return (
    <div className="p-4 space-y-6 animate-fade-in">
      <header className="text-center">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">
          Contacto y Soporte
        </h1>
        <p className="text-gray-300 mt-2">Estamos aquí para ayudarte a construir el hogar del futuro.</p>
      </header>

      <Card>
        <h2 className="text-xl font-semibold text-blue-300 mb-3">Soporte Proactivo DOMOTEK</h2>
        <p className="text-gray-400 text-sm mb-4">
          Con DOMOTEK Care, no solo reaccionamos a los problemas, los anticipamos. Nuestro sistema de IA monitorea constantemente la salud de tus dispositivos para garantizar un funcionamiento perfecto y predecir necesidades de mantenimiento.
        </p>
        <div className="text-center p-3 bg-blue-900/30 rounded-lg border border-blue-500/30">
            <p className="font-semibold text-white">Soporte 24/7 para clientes DOMOTEK Care.</p>
        </div>
      </Card>

      <Card>
        <h2 className="text-xl font-semibold text-blue-300 mb-4">Envíanos un Mensaje</h2>
        <form className="space-y-4">
          <div>
            <label htmlFor="name" className="text-sm font-medium text-gray-400 block mb-1">Nombre</label>
            <input type="text" id="name" className="w-full bg-slate-800/70 border border-slate-700 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors" />
          </div>
          <div>
            <label htmlFor="email" className="text-sm font-medium text-gray-400 block mb-1">Correo Electrónico</label>
            <input type="email" id="email" className="w-full bg-slate-800/70 border border-slate-700 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors" />
          </div>
          <div>
            <label htmlFor="message" className="text-sm font-medium text-gray-400 block mb-1">Mensaje</label>
            <textarea id="message" rows={4} className="w-full bg-slate-800/70 border border-slate-700 rounded-lg px-3 py-2 text-white focus:ring-2 focus:ring-blue-500 focus:outline-none transition-colors"></textarea>
          </div>
          <button type="submit" className="w-full flex justify-center items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-3 px-4 rounded-xl shadow-lg shadow-blue-500/20 hover:scale-105 transition-transform">
            <MailIcon className="w-5 h-5" />
            <span>Enviar Mensaje</span>
          </button>
        </form>
      </Card>
    </div>
  );
};

export default ContactScreen;
