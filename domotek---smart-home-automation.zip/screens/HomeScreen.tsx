import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import { CameraIcon, ChevronRightIcon, LightbulbIcon, ShoppingCartIcon, MenuIcon, ScanIcon } from '../components/Icons';
import { AreaChart, Area, ResponsiveContainer } from 'recharts';

const chartData = [
  { name: '1', uv: 400 },
  { name: '2', uv: 300 },
  { name: '3', uv: 600 },
  { name: '4', uv: 450 },
  { name: '5', uv: 700 },
];

const HomeScreen: React.FC = () => {
    const navigate = useNavigate();

  return (
    <div className="p-4 space-y-6">
      <header className="flex justify-between items-center text-white">
        <div className="font-bold text-xl tracking-wider">
          <span className="text-blue-400">»</span> DOMOTEK
        </div>
        <div className="flex items-center space-x-4">
            <ShoppingCartIcon className="w-6 h-6 text-gray-300"/>
            <MenuIcon className="w-6 h-6 text-gray-300"/>
        </div>
      </header>

      <div className="relative h-48 rounded-2xl overflow-hidden group">
        <img src="https://picsum.photos/id/10/400/300?blur=1" alt="Living room" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"/>
        <div className="absolute inset-0 bg-black/60 flex flex-col justify-center items-center p-4">
            <h1 className="text-3xl font-bold text-center text-white text-shadow" style={{textShadow: '0 0 10px rgba(59, 130, 246, 0.8)'}}>Hogares Proactivos y Sensibles</h1>
            <p className="text-center text-gray-300 mt-2">La inteligencia artificial al servicio de tu confort.</p>
        </div>
      </div>
      
      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Mi Hogar</h2>
          <ChevronRightIcon className="w-5 h-5 text-gray-400" />
        </div>
        <div className="grid grid-cols-2 gap-4">
            <Card className="bg-white/5" onClick={() => navigate('/routines')}>
                <h3 className="text-sm text-gray-300 font-medium">Consumo Energético</h3>
                <p className="text-2xl font-bold mt-1">25%</p>
                <p className="text-xs text-green-400">Ahorro este mes</p>
                 <div className="h-12 -mx-4 -mb-4 mt-2">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={chartData}>
                            <defs>
                                <linearGradient id="homeChartGradient" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.6}/>
                                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                                </linearGradient>
                            </defs>
                            <Area type="monotone" dataKey="uv" stroke="#38bdf8" strokeWidth={2} fill="url(#homeChartGradient)" />
                        </AreaChart>
                    </ResponsiveContainer>
                 </div>
            </Card>
             <Card className="bg-white/5">
                <h3 className="text-sm text-gray-300 font-medium">Dispositivos Conectados</h3>
                <p className="text-sm text-gray-400 mt-1">8 Activos</p>
                <div className="flex space-x-4 mt-4 text-gray-300">
                    <CameraIcon className="w-6 h-6"/>
                    <LightbulbIcon className="w-6 h-6 text-yellow-300"/>
                </div>
            </Card>
        </div>
      </section>

      <section>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Explorar y Mejorar</h2>
        </div>
         <div className="space-y-3">
             <Card className="flex justify-between items-center bg-white/5" onClick={() => navigate('/ai-scan')}>
                 <div className="flex items-center space-x-4">
                     <div className="bg-purple-500/20 p-2 rounded-lg"><ScanIcon className="w-6 h-6 text-purple-400"/></div>
                     <div>
                        <p className="font-semibold">Escanear mi hogar con IA</p>
                        <p className="text-xs text-gray-400">Recibe consejos para ahorrar energía.</p>
                     </div>
                 </div>
                 <ChevronRightIcon className="w-5 h-5 text-gray-400" />
             </Card>
         </div>
      </section>
      
      <button 
        onClick={() => navigate('/ar')}
        className="w-full flex justify-between items-center bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-3 px-4 rounded-xl shadow-lg shadow-blue-500/20 hover:scale-105 transition-transform">
        <span>Agendar Asesoría con RA</span>
        <ChevronRightIcon className="w-6 h-6"/>
      </button>
    </div>
  );
};

export default HomeScreen;