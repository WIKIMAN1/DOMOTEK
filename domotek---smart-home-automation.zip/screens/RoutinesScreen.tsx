import React from 'react';
import Card from '../components/Card';
import EnergyGauge from '../components/EnergyGauge';
import UsageChart from '../components/UsageChart';
import { ChevronRightIcon, BotIcon, HeartbeatIcon, HomeIcon } from '../components/Icons';

const RoutinesScreen: React.FC = () => {
  return (
    <div className="p-4 space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Rutinas y Ahorro</h1>
      </header>
      
      <Card className="flex items-center justify-between">
          <div>
              <h2 className="text-lg font-semibold">Clientes</h2>
              <p className="text-gray-400">120 clientes activos</p>
          </div>
          <div className="w-16 h-16 bg-slate-800 rounded-lg flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" className="text-teal-300"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
          </div>
      </Card>
      
      <section>
        <h2 className="text-xl font-semibold mb-2">Patrones de Uso Semanal</h2>
        <p className="text-sm text-gray-400 mb-4">Aprendizaje de Patrones: 80% completado</p>
        <UsageChart />
      </section>

      <section>
        <h2 className="text-xl font-semibold mb-4">Ahorro Energético</h2>
        <div className="grid grid-cols-2 gap-4">
            <Card className="flex flex-col items-center justify-center space-y-2 col-span-1">
                <EnergyGauge percentage={30} label="Ahorro Total" />
            </Card>
            <Card className="col-span-1 flex flex-col justify-center">
                <h3 className="font-bold text-md">Historial Total</h3>
                <p className="text-xs text-gray-400 mt-2">Controla tu hogar con sistemas más eficientes y automáticos.</p>
            </Card>
        </div>
      </section>
      
      <section>
        <h2 className="text-xl font-semibold mb-4">Patrones de Comportamiento Aprendidos</h2>
        <div className="space-y-3 mt-4">
            <Card className="flex items-center space-x-3">
                <div className="p-2 bg-pink-500/20 rounded-lg"><HeartbeatIcon className="w-6 h-6 text-pink-400"/></div>
                <div>
                    <h3 className="text-sm font-semibold">Monitoreo de Bienestar</h3>
                    <p className="text-xs text-gray-400">Si Papá no se levanta a las 9 AM, se enviará una alerta a Ana.</p>
                </div>
            </Card>
            <Card className="flex items-center space-x-3">
                <div className="p-2 bg-red-500/20 rounded-lg"><HomeIcon className="w-6 h-6 text-red-400"/></div>
                <div>
                    <h3 className="text-sm font-semibold">Rutina de Salida</h3>
                    <p className="text-xs text-gray-400">Al salir de casa por la mañana, se apagarán todas las luces y se bajará el termostato.</p>
                </div>
            </Card>
            <Card className="flex items-center space-x-3">
                <div className="p-2 bg-blue-500/20 rounded-lg"><BotIcon className="w-6 h-6 text-blue-400"/></div>
                <div>
                    <h3 className="text-sm font-semibold">Modo Ausente Optimizado</h3>
                    <p className="text-xs text-gray-400">Simulación de presencia y ahorro energético activado.</p>
                </div>
            </Card>
        </div>
      </section>
    </div>
  );
};

export default RoutinesScreen;