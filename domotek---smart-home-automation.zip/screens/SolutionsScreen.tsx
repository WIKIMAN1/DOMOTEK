import React from 'react';
import Card from '../components/Card';
import { HomeIcon, ShieldIcon, LayersIcon, BuildingIcon, HeartbeatIcon } from '../components/Icons';

const packages = [
  {
    icon: <HomeIcon className="w-8 h-8 text-purple-400" />,
    title: 'Home Starter Pack',
    description: 'Ideal para iniciarse en la domótica.',
    price: 90,
  },
  {
    icon: <ShieldIcon className="w-8 h-8 text-blue-400" />,
    title: 'Security Starter Pack',
    description: 'Tranquilidad esencial para el hogar.',
    price: 110,
  },
  {
    icon: <LayersIcon className="w-8 h-8 text-teal-400" />,
    title: 'Home Full Pack',
    description: 'La experiencia de hogar inteligente completa.',
    price: 215,
  },
  {
    icon: <BuildingIcon className="w-8 h-8 text-indigo-400" />,
    title: 'Business Pack',
    description: 'Eficiencia y modernidad para tu oficina.',
    price: 190,
  },
];

const SolutionsScreen: React.FC = () => {
  return (
    <div className="p-4 space-y-6">
      <header className="text-center">
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">Automatiza tu vida</h1>
        <p className="text-gray-300 mt-2 max-w-xs mx-auto">
          Descubre nuestros paquetes de automatización para el hogar y negocios.
        </p>
      </header>

      <div className="grid grid-cols-2 gap-4 text-left">
        {packages.map((pkg) => (
          <Card key={pkg.title} className="flex flex-col justify-between space-y-4">
            <div>
              <div className="bg-slate-800 w-12 h-12 rounded-lg flex items-center justify-center mb-4">
                {pkg.icon}
              </div>
              <h3 className="font-bold text-md">{pkg.title}</h3>
              <p className="text-xs text-gray-400 mt-1">{pkg.description}</p>
            </div>
            <div className="text-right">
                <p className="text-lg font-bold text-white">${pkg.price}</p>
                 <button className="w-full mt-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-2 px-4 rounded-lg text-sm hover:opacity-90 transition-opacity">
                    Ver detalles
                </button>
            </div>
          </Card>
        ))}
      </div>

      <Card className="text-left bg-gradient-to-br from-blue-500/20 to-purple-500/20">
         <div className="flex items-start space-x-4">
            <div className="bg-slate-800 w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0">
                <HeartbeatIcon className="w-8 h-8 text-green-400" />
            </div>
            <div>
                <h3 className="font-bold text-lg">DOMOTEK Care</h3>
                <p className="text-sm text-gray-300 mt-1">Nuestro servicio de soporte proactivo y predictivo. Monitoreamos tus dispositivos 24/7 para anticipar y resolver problemas antes de que ocurran, garantizando que tu hogar inteligente funcione siempre a la perfección.</p>
            </div>
        </div>
      </Card>
    </div>
  );
};

export default SolutionsScreen;